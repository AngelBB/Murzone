package com.ted.modelo.Articulo;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ArticuloDAO {
	
	public boolean insertarArticulo (Articulo articulo) {
		boolean rowInserted=false;
		try {
			//Statement stmt= getConnection("murzone").createStatement();
		//	String query="INSERT INTO articulo (id,nombre,pvp,familia,descripcion,imagen) VALUES (?,?,?,?,?,?)";
			String query="INSERT INTO articulo (id,nombre,pvp,familia,descripcion,imagen) VALUES (?,?,?,?,?,null)";
			Connection conn=getConnection("murzone");
			PreparedStatement statement = conn.prepareStatement(query);
			//statement.setString(1, null);
			statement.setString(1, articulo.getID());
			statement.setString(2, articulo.getNombre());
			statement.setDouble(3, articulo.getPvp());
			statement.setString(4, articulo.getFamilia().toString());
			statement.setString(5, articulo.getDescripcion());
			//statement.setBlob(5, articulo.getImagen());
			rowInserted = statement.executeUpdate() > 0;
			statement.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return rowInserted;
	}
	
	public boolean actualizarArticulo (Articulo articulo) {
		boolean rowInserted=false;
		try {
			//String query = "UPDATE articulo SET id=?,nombre=?,pvp=?,familia=?,descripcion=?,imagen=? WHERE id=?";
			String query = "UPDATE articulo SET nombre=?,pvp=?,familia=?,descripcion=? WHERE id=?";
			Connection conn=getConnection("murzone");
			PreparedStatement statement = conn.prepareStatement(query);
			statement.setString(1, articulo.getNombre());
			statement.setDouble(2, articulo.getPvp());
			statement.setString(3, articulo.getFamilia().toString());
			statement.setString(4, articulo.getDescripcion());
			statement.setString(5, articulo.getID());
			//statement.setBlob(6, articulo.getImagen());
			rowInserted = statement.executeUpdate() > 0;
			statement.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
			return rowInserted;
	}
	
	public boolean borrarArticulo (String id_articulo) {
		boolean rowEliminar=false;
		try {
			String query=" DELETE FROM articulo WHERE id=?";
			Connection conn=getConnection("murzone");
			PreparedStatement statement = conn.prepareStatement(query);
			statement.setString(1, id_articulo);
			rowEliminar = statement.executeUpdate() > 0;
			statement.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return rowEliminar;
	}	
	
	public List<Articulo> consultarArticulo (){
		List<Articulo> articulos=new ArrayList<>();
		try {
			Connection conn=getConnection("murzone");
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery("select * from articulo");
			while (rs.next()) {
				String id = rs.getString("id");
				String nombre = rs.getString("nombre");
				Double precio = rs.getDouble("pvp");
				Familia familia = Familia.valueOf(rs.getString("familia"));
				String descripcion = rs.getString("descripcion");
				Blob imagen=rs.getBlob("imagen");
				articulos.add(new Articulo(id,nombre,precio ,familia ,descripcion,imagen));				
			}
			stmt.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return articulos;
	}
	
	public List<Articulo> consultarArticuloPVP (double pvp){
		List<Articulo> articulos=new ArrayList<>();
		try {
			Connection conn=getConnection("murzone");
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery("select * from articulo where pvp="+pvp);
			while (rs.next()) {
				String id = rs.getString("id");
				String nombre = rs.getString("nombre");
				Double precio = rs.getDouble("pvp");
				Familia familia = Familia.valueOf(rs.getString("familia"));
				String descripcion = rs.getString("descripcion");
				Blob imagen=rs.getBlob("imagen");
				articulos.add(new Articulo(id,nombre,precio ,familia ,descripcion,imagen));				
			}
			stmt.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return articulos;
	}
	public List<Articulo> consultarArticuloNombre (String nombre){
		List<Articulo> articulos=new ArrayList<>();
		try {
			Connection conn=getConnection("murzone");
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery("select * from articulo where nombre='"+nombre+"'");
			while (rs.next()) {
				String id = rs.getString("id");
				String nombree = rs.getString("nombre");
				Double precio = rs.getDouble("pvp");
				Familia familia = Familia.valueOf(rs.getString("familia"));
				String descripcion = rs.getString("descripcion");
				Blob imagen=rs.getBlob("imagen");
				articulos.add(new Articulo(id,nombree,precio ,familia ,descripcion,imagen));				
			}
			stmt.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return articulos;
	}
	
	private Connection getConnection(String base_datos) {
		Connection conn = null;
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:comp/env");
			DataSource ds = (DataSource) envContext.lookup("jdbc/"+base_datos);
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }
		return conn;
	}

	public Articulo consultarArticulo(String id) {
		Articulo articulo=null;
		try {
			Connection conn=getConnection("murzone");
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery("select * from articulo where id='"+id+"'");
			while (rs.next()) {
				String idd = rs.getString("id");
				String nombree = rs.getString("nombre");
				Double precio = rs.getDouble("pvp");
				Familia familia = Familia.valueOf(rs.getString("familia"));
				String descripcion = rs.getString("descripcion");
				Blob imagen=rs.getBlob("imagen");
				articulo=new Articulo(idd,nombree,precio ,familia ,descripcion,imagen);				
			}
			stmt.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return articulo;
	}
}
