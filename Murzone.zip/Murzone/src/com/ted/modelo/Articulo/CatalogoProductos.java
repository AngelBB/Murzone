package com.ted.modelo.Articulo;

import java.util.List;

public class CatalogoProductos {
	private List<Articulo> articulos;
	private static CatalogoProductos catalogo;
	
	private CatalogoProductos(List<Articulo> articulos) {
		this.articulos=articulos;
	}
	public static CatalogoProductos getSingletonInstance() {
		if(catalogo == null) {
			
			//List<Articulo> articulos;
			//catalogo = new CatalogoProductos(articulos);
		}else {
			System.out.println("No se puede crear el objeto , porque ya hay una instancia.");
		}
		return catalogo;
	}	
}
