package com.ted.modelo.Articulo;

import java.util.ArrayList;
import java.util.List;


public class CarritoCompra {
	private List<Articulo> articulos;
	public CarritoCompra() {
		articulos=new ArrayList<>();
	}
	public CarritoCompra(List<Articulo> articulos) {
		super();
		this.articulos = articulos;
	}
	public List<Articulo> getArticulos() {
		return articulos;
	}
	public void setArticulos(List<Articulo> articulos) {
		this.articulos = articulos;
	}
	public boolean insertarArticulo(Articulo articulo) {
		return articulos.add(articulo);
	}
	public boolean eliminarArticulo(Articulo articulo) {
		return articulos.remove(articulo);
	}
	public Articulo eliminarArticulo(int indice) {
		return articulos.remove(indice);
	} 
	public void vaciar() {
		articulos.clear();
	}
}
