package com.ted.modelo.Articulo;

public enum Familia {
	SOBREMESA,
	PORTATIL,
	SMARTPHONE,
	DISCO_DURO,
	ELECTRODOMESTICO
}
