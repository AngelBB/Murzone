package com.ted.modelo.Usuario;

import java.io.Serializable;

import com.ted.modelo.Articulo.CarritoCompra;

public class Cliente extends Usuario implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private FormaPago forma_pago;
	private CarritoCompra carrito;
	
	public Cliente() {
		super();
		carrito=new CarritoCompra();
	}
	
	public Cliente(String nombre, String email, String password,boolean es_admin,FormaPago fp,CarritoCompra cc) {
		super(nombre, email, password,es_admin);
		forma_pago=fp;
		if(cc == null)
			carrito=new CarritoCompra();
	}
	public FormaPago getForma_pago() {
		return forma_pago;
	}

	public void setForma_pago(FormaPago forma_pago) {
		this.forma_pago = forma_pago;
	}

	public CarritoCompra getCarrito() {
		return carrito;
	}

	public void setCarrito(CarritoCompra carrito) {
		this.carrito = carrito;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((carrito == null) ? 0 : carrito.hashCode());
		result = prime * result + ((forma_pago == null) ? 0 : forma_pago.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente other = (Cliente) obj;
		if (carrito == null) {
			if (other.carrito != null)
				return false;
		} else if (!carrito.equals(other.carrito))
			return false;
		if (forma_pago != other.forma_pago)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Cliente ["+super.toString()+" forma_pago=" + forma_pago + ", carrito=" + carrito + "]";
	}
	
	
}
