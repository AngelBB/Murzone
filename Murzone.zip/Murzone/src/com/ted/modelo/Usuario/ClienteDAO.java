package com.ted.modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.ted.modelo.Articulo.CarritoCompra;

public class ClienteDAO {
	public boolean borrarCliente (Cliente cliente) {
		boolean rowEliminar=false;
		try {
			String query="DELETE FROM cliente WHERE email=?";
			Connection conn=getConnection("murzone");
			PreparedStatement statement = conn.prepareStatement(query);
			statement.setString(1, cliente.getEmail());
			rowEliminar = statement.executeUpdate() > 0;
			statement.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return rowEliminar;
	}
	
	public boolean borrarCliente (String email) {
		boolean rowEliminar=false;
		try {
			String query="DELETE FROM cliente WHERE email=?";
			Connection conn=getConnection("murzone");
			PreparedStatement statement = conn.prepareStatement(query);
			statement.setString(1, email);
			rowEliminar = statement.executeUpdate() > 0;
			statement.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return rowEliminar;
	}
	
	public List<Cliente> consultarCliente (){
		List<Cliente> clientes=new ArrayList<>();
		try {
			Connection conn=getConnection("murzone");
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery("select * from cliente");
			while (rs.next()) {
				clientes.add(new Cliente(rs.getString("nombre"),rs.getString("email")
						,rs.getString("password"),rs.getBoolean("es_admin"),FormaPago.valueOf(rs.getString("pago").toUpperCase()),new CarritoCompra()));
			}
			stmt.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return clientes;
	}
	
	public Cliente consultarCliente (String email){
		Cliente cliente=null;
		try {
			Connection conn=getConnection("murzone");
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery("select * from cliente where email="+email);
			if(rs.next()) {
				cliente=new Cliente(rs.getString("nombre"),rs.getString("email")
					,rs.getString("password"),rs.getBoolean("es_admin"),FormaPago.valueOf(rs.getString("pago")),new CarritoCompra());
			}
			stmt.close();
			conn.close();
		} catch (SQLException e) {
		    e.printStackTrace();
	    }catch (Exception e) {
	   		e.printStackTrace();
		}
		return cliente;
	}
	private Connection getConnection(String base_datos) {
		Connection conn = null;
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:comp/env");
			DataSource ds = (DataSource) envContext.lookup("jdbc/"+base_datos);
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }
		return conn;
	}
	public Cliente validate(String email ,String password) {
		Cliente cliente=null;
		try {
			Connection con = getConnection("murzone");
			PreparedStatement ps = con.prepareStatement("select * from cliente where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				cliente=new Cliente(rs.getString("nombre"),rs.getString("email")
						,rs.getString("password"),rs.getBoolean("es_admin"),FormaPago.valueOf(rs.getString("pago").toUpperCase()),new CarritoCompra());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cliente;
	}

	public boolean registrar(String nombre, String email, String password, boolean es_admin, FormaPago fp) {
		boolean check=false;
		try {
			String query="INSERT INTO cliente VALUES(?,?,?,?,?)";
			Connection conn=getConnection("murzone");
			PreparedStatement statement = conn.prepareStatement(query);
			statement.setString(1, email);
			statement.setString(2, nombre);
			statement.setString(3, password);
			statement.setString(4, fp.toString().toLowerCase());
			statement.setBoolean(5, es_admin);
			check = statement.executeUpdate() > 0;
			statement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return check;
	}
}
