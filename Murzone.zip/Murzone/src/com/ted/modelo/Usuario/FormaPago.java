package com.ted.modelo.Usuario;

public enum FormaPago {
	TARJETA,EFECTIVO,CONTRAREEMBOLSO,PAYPAL
}
