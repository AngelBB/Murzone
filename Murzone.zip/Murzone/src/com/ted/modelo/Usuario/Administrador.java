package com.ted.modelo.Usuario;

import com.ted.modelo.Articulo.ArticuloDAO;

public class Administrador extends Usuario {
	private ArticuloDAO dao_articulo=new ArticuloDAO();
	private ClienteDAO dao_cliente=new ClienteDAO();
	
	public Administrador() {
		super();
	}
	public Administrador(String nombre, String email, String password,boolean es_admin) {
		super(nombre, email, password,es_admin);
		// TODO Auto-generated constructor stub
	}
	public ArticuloDAO getDao_articulo() {
		return dao_articulo;
	}
	public void setDao_articulo(ArticuloDAO dao_articulo) {
		this.dao_articulo = dao_articulo;
	}
	public ClienteDAO getDao_cliente() {
		return dao_cliente;
	}
	public void setDao_cliente(ClienteDAO dao_cliente) {
		this.dao_cliente = dao_cliente;
	}
}
