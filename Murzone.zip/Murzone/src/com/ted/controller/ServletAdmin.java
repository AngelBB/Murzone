package com.ted.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ted.modelo.Articulo.Articulo;
import com.ted.modelo.Articulo.Familia;
import com.ted.modelo.Usuario.Administrador;
import com.ted.modelo.Usuario.Cliente;



@WebServlet(urlPatterns = {"/admin_cliente/ServletAdmin", "/admin_articulo/ServletAdmin"})
public class ServletAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Administrador admin=new Administrador();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletAdmin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		switch (request.getParameter("action")) {
			case "go_update":
				RequestDispatcher dispatcher = request.getRequestDispatcher("/admin_articulo/UpdateArticulo.jsp");
				Articulo articulo=admin.getDao_articulo().consultarArticulo(request.getParameter("id"));
				request.setAttribute("articulo", articulo);
				dispatcher.forward(request, response);
				break;
			case "eliminar": 
				admin.getDao_articulo().borrarArticulo(request.getParameter("id"));
				List<Articulo> articulo1=admin.getDao_articulo().consultarArticulo();
				request.setAttribute("articulo", articulo1);
				request.getRequestDispatcher("/admin_articulo/ResultArticulo.jsp").forward(request, response);
				break;
			case "editar": 
				admin.getDao_articulo().actualizarArticulo(new Articulo(request.getParameter("id"),
						request.getParameter("nombre"),
						Double.parseDouble(request.getParameter("pvp"))
						,Familia.valueOf(request.getParameter("familia").toUpperCase()),
						request.getParameter("descripcion"),null));
						request.getRequestDispatcher("/admin_articulo/UpdateArticulo.jsp").forward(request, response);
				break;
			case "insertar":
				admin.getDao_articulo().insertarArticulo(new Articulo(request.getParameter("id"),
						request.getParameter("nombre"),
						Double.parseDouble(request.getParameter("pvp"))
						,Familia.valueOf(request.getParameter("familia").toUpperCase()),
						request.getParameter("descripcion"),null));	
				request.getRequestDispatcher("/admin_articulo/InsertArticulo.jsp").forward(request, response);
				break;	
			case "consultar":
				if((request.getParameter("mostrar_articulos")!=null) && (request.getParameter("mostrar_articulos").equals("all_articles"))) {
					List<Articulo> listaArticulos=admin.getDao_articulo().consultarArticulo();
					RequestDispatcher dispatcher1 = request.getRequestDispatcher("/admin_articulo/ResultArticulo.jsp");
					request.setAttribute("lista", listaArticulos);
					dispatcher1.forward(request, response);
				}else {
					if((request.getParameter("pvp") != null) && (!request.getParameter("pvp").equals(""))) {
						List<Articulo> listaArticulos=admin.getDao_articulo().consultarArticuloPVP(Double.parseDouble(request.getParameter("pvp")));
						RequestDispatcher dispatcher1 = request.getRequestDispatcher("/admin_articulo/ResultArticulo.jsp");
						request.setAttribute("lista", listaArticulos);
						dispatcher1.forward(request, response);
					}else if((request.getParameter("nombre") != null) && (!request.getParameter("nombre").equals(""))) {
						List<Articulo> listaArticulos=admin.getDao_articulo().consultarArticuloNombre(request.getParameter("nombre"));
						RequestDispatcher dispatcher2 = request.getRequestDispatcher("/admin_articulo/ResultArticulo.jsp");
						request.setAttribute("lista", listaArticulos);
						dispatcher2.forward(request, response);
					}
				}
				break;
			case "consultar_cliente": 
				if(request.getParameter("mostrar_clientes").equals("all_clients")) {
					List<Cliente> clientes=admin.getDao_cliente().consultarCliente();
					RequestDispatcher dispatcher3 = request.getRequestDispatcher("/admin_cliente/ResultCliente.jsp");
					request.setAttribute("lista", clientes);
					dispatcher3.forward(request, response);
					
				}else {
					Cliente cliente=admin.getDao_cliente().consultarCliente(request.getParameter("email"));
					RequestDispatcher dispatcher3 = request.getRequestDispatcher("/admin_cliente/ResultCliente.jsp");
					request.setAttribute("lista", cliente);
					dispatcher3.forward(request, response);
				}
				break;
			case "eliminar_cliente":
				admin.getDao_cliente().borrarCliente(request.getParameter("email"));
				request.getRequestDispatcher("/admin_cliente/ResultCliente.jsp").forward(request, response);
				break;
			default:
				System.out.println("ERROR en el switch");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
