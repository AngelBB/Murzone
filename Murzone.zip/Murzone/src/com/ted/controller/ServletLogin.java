package com.ted.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ted.modelo.Usuario.Administrador;
import com.ted.modelo.Usuario.Cliente;
import com.ted.modelo.Usuario.ClienteDAO;
import com.ted.modelo.Usuario.FormaPago;
import com.ted.modelo.Usuario.Usuario;

/**
 * Servlet implementation class ServletLogin
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ClienteDAO clienteDAO=new ClienteDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		switch(request.getParameter("action")) {
			case "acceso": 
				Cliente cliente=clienteDAO.validate(request.getParameter("email"), request.getParameter("password"));
				if(cliente!=null) {
					if(cliente.getEsAdmin()) {
						HttpSession session = request.getSession();
						Administrador admin=new Administrador(cliente.getNombre(),cliente.getEmail(),cliente.getPassword(),cliente.getEsAdmin());
						session.setAttribute("administrador", admin);
						RequestDispatcher dispatcher = request.getRequestDispatcher("index_admin.jsp");
						dispatcher.forward(request, response);
					}else {
						HttpSession session = request.getSession();
						session.setAttribute("cliente", cliente);
						RequestDispatcher dispatcher = request.getRequestDispatcher("index_cliente.jsp");
						dispatcher.forward(request, response);
					}
				}else {
					RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
					dispatcher.forward(request, response);
				}
				break;
			case "registro":
				clienteDAO.registrar(request.getParameter("nombre"),request.getParameter("email"), 
						request.getParameter("password"),false,
						FormaPago.valueOf(request.getParameter("forma_pago").toUpperCase()));
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
				break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
