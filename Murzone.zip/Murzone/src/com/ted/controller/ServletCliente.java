package com.ted.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ted.modelo.Articulo.Articulo;
import com.ted.modelo.Articulo.ArticuloDAO;
import com.ted.modelo.Usuario.Cliente;

/**
 * Servlet implementation class ServletUsuario
 */
@WebServlet("/ServletCliente")
public class ServletCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Cliente cliente=new Cliente();
	private ArticuloDAO articuloDAO=new ArticuloDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCliente() {
    	super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		switch(request.getParameter("action")) {
			case "rellenar_carrito":				
				String [] ids=request.getParameterValues("articulo");
				for(String id:ids) {
					cliente.getCarrito().insertarArticulo(articuloDAO.consultarArticulo(id));
				}
				request.getRequestDispatcher("/cliente/Catalogo.jsp").forward(request, response);
			break;
			case "comprar":
				//Rescatamos de la sesion al cliente
				/*HttpSession session=request.getSession();
				cliente=(Cliente)session.getAttribute("cliente");*/
				//Recuperamos su carrito
				List<Articulo> articulos=cliente.getCarrito().getArticulos();
				request.setAttribute("lista", articulos);
				request.setAttribute("total_compra",calcularTotal(articulos));
				//request.setAttribute("cliente", cliente);
				request.getRequestDispatcher("/cliente/Carrito.jsp").forward(request, response);
			break;
			case "catalogo": 
				List<Articulo> articulos_=articuloDAO.consultarArticulo();
				request.setAttribute("lista", articulos_);
				request.getRequestDispatcher("/cliente/Catalogo.jsp").forward(request, response);
			break;
		}
	}

	private double calcularTotal(List<Articulo> articulos) {
		double total=0;
		for(Articulo articulo:articulos) {
			total+=articulo.getPvp();
		}
		return total;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
